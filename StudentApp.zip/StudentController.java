import java.util.Hashtable;
import java.util.List;

public class StudentController{
    
    public static List<Student> get(Hashtable <String ,Object> ht){

        List<Student> student;
        if(ht == null){
            student = StudentDao.getAll();
        }else{
            String name = (String) ht.get("n");
            Gender genders =(Gender) ht.get("gender");

            if(genders ==null)
                student = StudentDao.getByName(name);
            else if(name ==null)
                student = StudentDao.getAllByGender(genders);
            else
                student = StudentDao.getNameAndGender(name, genders);
            
        }
        
       
        return student;
    }
    
    
}
