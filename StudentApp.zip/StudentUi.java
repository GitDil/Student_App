import javax.swing.AbstractButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

//import javafx.scene.paint.Color;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class StudentUi extends JFrame {

    JTable tblStudent;
    JComboBox cmbStudent;
    JTextField txtSearchName;
     Vector vd1;

    StudentUi() {

        setTitle("Student- App");
        setLocation(500, 300);
        setSize(530, 300);

         vd1 = new Vector<>();
        vd1.add("Name");
        vd1.add("Address");
        vd1.add("Stream");
        vd1.add("Gender");

        Vector data = new Vector<>();

        txtSearchName = new JTextField(10);
        JLabel lblName = new JLabel("Search By Name ");
        JLabel lblGender = new JLabel("Search Gender");
        cmbStudent = new JComboBox<>();
        JButton btnSearch = new JButton("Search");
        JButton btnCancel = new JButton("Cancel");

        tblStudent = new JTable();
        DefaultTableModel tblModel = new DefaultTableModel(data, vd1);
        tblStudent.setModel(tblModel);

        JScrollPane jsptable = new JScrollPane();
        jsptable.setPreferredSize(new Dimension(500, 700));
        jsptable.setViewportView(tblStudent);

        JTableHeader tableHeader = tblStudent.getTableHeader();
        tableHeader.setBackground(Color.GREEN);

        Font headerFont = new Font("TimesNewRomance", Font.BOLD, 14);
        tableHeader.setFont(headerFont);

        tblStudent.setSelectionBackground(Color.YELLOW);
        tblStudent.setSelectionForeground(Color.MAGENTA);

        Container con = getContentPane();
        FlowLayout lay = new FlowLayout();
            con.setLayout(lay);
            con.add(lblName);
            con.add(txtSearchName);
            con.add(lblGender);
            con.add(cmbStudent);
            con.add(btnCancel);
            con.add(btnSearch);
            con.add(jsptable);

        btnSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnSearchAp(e);
            }
        });

        btnCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnCancelAp(e);
            }
        });

        initialize();
        // tblStudent.getSelectionModel().addListSelectionListener(new
        // ListSelectionListener() {
        // public void valueChanged(ListSelectionEvent e) {

        // int selectedrow = tblStudent.getSelectedRow();
        // Vector row1 = new Vector<>();
        // row1.add(stu.getName());
        // row1.add(stu.getAddress());
        // row1.add(stu.getStream());
        // row1.add(stu.getGender().getName());

        // if (selectedrow >= 0) {
        // JOptionPane.showMessageDialog(null, "SELECETD Row is" + selectedrow);
        // }
        // }

        // });

    }

    public void initialize() {
        loadView();
    }

    public void loadView() {
        List<Student> stulist = StudentController.get(null);
        fillTable(stulist);

        List<Gender> genlist = GenderContoller.get();

        Vector<Object> genders = new Vector<>();
        genders.add("Select a gender");
        for (Gender gen : genlist) {
            genders.add(gen);
        }

        DefaultComboBoxModel<Object> genModel1 = new DefaultComboBoxModel<>(genders);
        cmbStudent.setModel(genModel1);
    }

    public void fillTable(List<Student> stulist) {

        Vector data = new Vector<>();
        for (Student stu : stulist) {
            Vector row = new Vector<>();
            row.add(stu.getName());
            row.add(stu.getAddress());
            row.add(stu.getStream());
            row.add(stu.getGender().getName());
            data.add(row);
        }
        DefaultTableModel model = new DefaultTableModel(data,vd1);
        tblStudent.setModel(model);
    }

    public void btnSearchAp(ActionEvent e) {
        Gender gender = null;
        String name = txtSearchName.getText();

        Hashtable<String, Object> ht = new Hashtable<>();
        ht.put("n", name);

        Object sitem = cmbStudent.getSelectedItem();

        if (!sitem.equals("Select a Gender"))
            gender = (Gender) sitem;

        if (gender != null){
            ht.put("gender", gender);}
        List<Student> student = StudentController.get(ht);

        fillTable(student);
    }

    public void btnCancelAp(ActionEvent e) {

        cmbStudent.setSelectedIndex(0);
        txtSearchName.setText("");

        List<Student> student = StudentController.get(null);

        fillTable(student);

    }

}

// tblStudent.getSelectionModel().addListSelectionListener(new
// ListSelectionListener() {
// public void valueChanged(ListSelectionEvent e) {

// int selectedrow = tblStudent.getSelectedRow();
// for()
// Vector row1 = new Vector<>();
// row1.get(stu.getName());
// row1.get(stu.getAddress());
// row1.get(stu.getStream());
// row1.get(stu.getGender().getName());

// if (selectedrow >= 0) {
// JOptionPane.showMessageDialog(null, "SELECETD Row is" + selectedrow);
// }
// }

// });

// }
