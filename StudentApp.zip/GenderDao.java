import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;
import java.util.ArrayList;

public class GenderDao {
    
    public static Gender getById(int id) {

        Gender gender = new Gender();

        try {

            // Connection con = DriverManager.getConnection("jdbc:mysql://localhost/colleage", "root", "1234");
            // Statement stm = con.createStatement();
            String qry = "SELECT * FROM gender where id=" + id;
            ResultSet result = CommonDao.get(qry);

            result.next();
            gender.setID(result.getInt("id"));
            gender.setName(result.getString("name"));

        } catch (SQLException e) {
            System.out.println("Cant acess the database" + e.getMessage());
        }

        return gender;
    }

    public static List<Gender> getAll(){
        List <Gender> genders = new ArrayList<Gender>();

        try{
            String qry = "SELECT * from Gender";
            ResultSet result = CommonDao.get(qry);

            while(result.next()){
                Gender gen = new Gender();
                gen.setID((result.getInt("id")));
                gen.setName(result.getString("name"));
                genders.add(gen);
                
            }
        }catch(SQLException e){
            System.out.println();
        }

        return genders;
    }

    // public static Object getById(String string) {
    // return null;
    // }

}
