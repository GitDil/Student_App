import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

public class StudentDao {
    private static List<Student> get(String qry) {
        List<Student> students = new ArrayList<>();

        try {
            ResultSet result = CommonDao.get(qry);

            while (result.next()){
                Student stu = new Student();
                stu.setID(result.getInt("id"));
                stu.setName(result.getString("name"));
                stu.setAddress(result.getString("address"));
                stu.setStream(result.getString("stream"));
                stu.setGender(GenderDao.getById(result.getInt("gender_id")));

                students.add(stu);
            }

        } catch (SQLException e) {
            System.out.println("Cant Acess Database" + e.getMessage());
        }

        return students;
    }

    public static List<Student> getAll() {
        String qry = "SELECT * from student";
        List<Student> students = get(qry);
        return students;
    }

    public static List<Student> getByName(String name){
        String qry = "SELECT * From student where name like '" + name + "%'";
        List <Student> students = get(qry);
        return students;
    }

    public static List<Student> getAllByGender(Gender gender){
        String qry = "SELECT * FROM employee where gender_id=" + gender.getID();
        List <Student> students = get(qry);
        return students;
    }

    public static List<Student> getNameAndGender(String name,Gender gender){
        String qry = "SELECT * From student where name like '" + name + "%' and gender_id="+gender.getID();
        List <Student> students = get(qry);
        return students;
    }

}
