import java.util.Hashtable;
import java.util.List;

public class ST {
    public static void main(String[] args) {
       
        Hashtable<String,Object> ht = new Hashtable<>();
        ht.put("name", "Sunil");
        List<Student> students = StudentController.get(ht);
        for(Student stu:students){
            System.out.println(stu.getID() + " ");
            System.out.println(stu.getName() + " ");
            System.out.println(stu.getAddress() + " ");
            System.out.println(stu.getStream() + " ");
            System.out.println(stu.getGender().getName() + " ");
        }
    }
}
