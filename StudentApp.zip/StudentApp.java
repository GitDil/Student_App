
public class StudentApp{
    public static void main(String[] args) {
        
        StudentUi stuui = new StudentUi();
        stuui.setDefaultCloseOperation(stuui.EXIT_ON_CLOSE);
        stuui.setVisible(true);
    };

}
