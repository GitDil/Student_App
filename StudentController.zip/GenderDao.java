import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GenderDao {
    // public static Object result;

    public static Gender getByName(int id) {

        Gender gender = new Gender();

        try {

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/colleage", "root", "1234");
            Statement stm = con.createStatement();
            String qry = "SELECT * FROM gender where id=" + id;
            ResultSet result = stm.executeQuery(qry);

            result.next();
            gender.setID(result.getInt("id"));
            gender.setName(result.getString("name"));

        } catch (SQLException e) {
            System.out.println("Cant acess the database" + e.getMessage());
        }

        return gender;
    }

    // public static Object getById(String string) {
    // return null;
    // }

}
