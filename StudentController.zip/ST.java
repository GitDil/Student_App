import java.util.List;

public class ST {
    public static void main(String[] args) {
        List<Student> students = StudentDao.getAll();

        for(Student stu:students){
            System.out.println(stu.getID() + " ");
            System.out.println(stu.getName() + " ");
            System.out.println(stu.getAddress() + " ");
            System.out.println(stu.getStream() + " ");
            System.out.println(stu.getGender().getName() + " ");
        }
    }
}
