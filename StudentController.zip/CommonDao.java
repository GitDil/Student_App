
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


public class CommonDao {
    public static  ResultSet get(String qry){

        ResultSet result = null;

        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/colleage","root","1234");
            Statement stm = con.createStatement();
            result = stm.executeQuery(qry);

            //String qry = "SELECT *from student";

        }catch(SQLException e){
            System.out.println("Cant Acess Database"+e.getMessage());
        }


        return result;
    }

    // public static ResultSet getAll() {
    //     return null;
    // }
}
