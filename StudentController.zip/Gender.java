public class Gender {
     private int id;
     private String name;

    Gender(){}

    public void setID(int id){
        this.id = id;
    }
    public int getID(){
        return id;
    }

    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
}
