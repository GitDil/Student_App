public class Student{
   private  int id;
   private  String name;
   private String address;
  private   String stream;
    private Gender gender;

    Student(){}

    public void  setID(int id){
         this.id = id;
    }
    public int getID(){
        return id;
    }


    public void setName(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }

    public void setAddress(String address){
        this.address = address;
    }
    public String getAddress(){
        return address;
    }


    public void setStream(String stream){
        this.stream = stream;
    }
    public String getStream(){
        return stream;
    }

    public void setGender(Gender gender){
        this.gender =gender;
    }

    public Gender getGender(){
        return gender;
    }


}