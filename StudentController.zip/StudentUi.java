import javax.swing.JFrame;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;

import java.util.List;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class StudentUi extends JFrame {

    JTable tblStudent;

    StudentUi() {

        setTitle("Student- App");
        setLocation(300, 400);
        setSize(400, 500);

        Vector vd1 = new Vector<>();
        vd1.add("name");
        vd1.add("address");
        vd1.add("stream");
        vd1.add("gender");

        Vector data = new Vector<>();

        tblStudent = new JTable();
        DefaultTableModel tblModel = new DefaultTableModel(data, vd1);
        tblStudent.setModel(tblModel);

        JScrollPane jsptable = new JScrollPane();
        jsptable.setPreferredSize(new Dimension(500,700));
        jsptable.setViewportView(tblStudent);

        Container con = getContentPane();
        FlowLayout lay = new FlowLayout();
        con.setLayout(lay);

        con.add(jsptable);

        initialize();
    }

    public void initialize(){
        loadView();
    }

    public void loadView(){
        List<Student> stulist = StudentController.get();
        fillTable(stulist);
    }

    public void fillTable(List<Student> stulist){
        DefaultTableModel model1 = (DefaultTableModel)tblStudent.getModel();
        for(Student stu: stulist){
            Vector row = new Vector<>();
            row.add(stu.getName());
            row.add(stu.getAddress());
            row.add(stu.getStream());
            row.add(stu.getGender().getName());
            model1.addRow(row);
        }
    }

}

